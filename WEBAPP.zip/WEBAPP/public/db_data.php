<?php
class DbData
{
    public $database='dbtest',$host='localhost', $user='root',$password='';
}
?>
