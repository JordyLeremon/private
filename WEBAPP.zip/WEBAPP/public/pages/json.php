<?php

$array1 = array(1, 2);
$array2 = array(3, 4);
$array = array($array1,$array2);
print_r($array[0][0]);
print_r($array[0][1]);
print_r($array[1][0]);
print_r($array[1][1]);

?>