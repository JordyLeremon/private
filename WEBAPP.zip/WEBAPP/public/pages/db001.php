<?php

	$dbHost = "localhost";

	$dbDatabase = "dbtest";

	$dbPasswrod = "";

	$dbUser = "root";


	$mysqli = mysqli_connect($dbHost, $dbUser, $dbPasswrod, $dbDatabase);
	

?>