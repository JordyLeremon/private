<?php
        		                                               
                                        		                for ($i=0;$i<count($type_id);$i++){
								       		//echo '<option value='.$
									       		echo '<option value='.$i.'>'.$type_id[$i].'</option>';
										}
									
                		                                ?>
<?php
        		                                               
                        		                                
                                        		                for ($i=0;$i<count($sensors_id);$i++){
								       		//echo '<option value='.$i.'>'.$sensors_serials2[$i].'</option>';
                                                        			
									       		echo '<option value='.$i.'>'.$sensors_id[$i].'</option>';
										
									}
                		                                ?>