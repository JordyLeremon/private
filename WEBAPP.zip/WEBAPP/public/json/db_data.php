<?
class DbData
{
    public $database='dbtest',$host='localhost', $user='pierre',$password='breton974';
}
?>
